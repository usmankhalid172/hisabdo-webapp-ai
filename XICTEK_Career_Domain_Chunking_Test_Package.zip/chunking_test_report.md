# Career Domain Chunking Test Report
**Project:** XICTEK Systems — Careers & Job Openings Knowledge Base  
**Prepared:** 2026-11-10  
**Status:** Initial structural test; production approval pending HR content and tokenizer validation

## 1. Objective
Evaluate heading-aware chunking for recruitment FAQs and job-role requirement lists. The target is to keep each FAQ question with its answer, keep each job's title and criteria together, preserve useful context when long sections must split, and prevent content from one role leaking into another.

## 2. Source corpus and limitations
The public Careers page currently exposes four role cards:
- Senior Full-Stack Developer — Full-time, Remote; React, Next.js, .NET, PostgreSQL.
- Mobile App Developer — Full-time, Remote; Flutter, React Native, iOS, Android.
- Cloud Solutions Architect — Full-time, Remote; Azure, AWS, DevOps, Terraform.
- UI/UX Designer — Full-time, Remote; Figma, Design Systems, Prototyping.

Source: https://www.xicteksystems.com/careers

The reviewed public page presents compact role cards and technology tags, not detailed responsibilities or full qualification lists. A dedicated approved Careers FAQ corpus was not available in the material reviewed for this test. Therefore:
- The role-card structures could be tested for boundary preservation.
- Full job-criteria list chunking could not be empirically validated because full criteria text was not present.
- FAQ chunking could only be specified as a parsing rule; it was not benchmarked against real approved FAQ text.
- No claim is made that these settings have been tested against the production vector database, embedding model, or exact production tokenizer.

## 3. Test method
A deterministic, heading-aware structural fixture was used. The test checks the following:
1. Each role starts a new document/section.
2. Role title and its metadata remain attached to that role's content.
3. A chunk must not contain content from two different job roles.
4. A heading is not emitted as an orphan chunk.
5. When a long section must split, the preceding heading/context is repeated in the continuation.
6. FAQ question and answer are treated as one atomic unit and must not be split across chunks.

**Token measurement caveat:** The comparison bands below are design configurations, not tokenizer-measured production results. Word-count estimates are not interchangeable with tokens. Re-run using the actual tokenizer and production parser before deployment.

## 4. Configurations compared

| Configuration | Target chunk size | Overlap | Intended use | Assessment |
|---|---:|---:|---|---|
| A — Small | 150 tokens | 20 tokens | Short FAQs, compact role cards | High boundary precision; may create excess fragments for long policy answers |
| B — Balanced | 300 tokens | 40 tokens | Default for careers content | Recommended starting point; keeps short role records intact and provides modest continuity |
| C — Large | 500 tokens | 60 tokens | Long hiring policies or detailed job descriptions | More context per chunk; greater risk of mixing unrelated sections if boundaries are ignored |

These are starting parameters, not measured token counts from an embedding tokenizer.

## 5. Structural test results

| Test ID | Test | Expected result | Outcome |
|---|---|---|---|
| CH-01 | Split at each job-role heading | Each role is an independent section | PASS — recommended parser rule |
| CH-02 | Preserve role title with its tags/criteria | Title and associated fields stay together | PASS for published role-card data |
| CH-03 | Prevent cross-role contamination | No chunk includes two different role records | PASS when role-level document boundaries are enforced |
| CH-04 | FAQ question-answer pairing | One FAQ pair remains atomic | RULE DEFINED — real FAQ corpus unavailable |
| CH-05 | Long criteria-list continuation | Continuation repeats role title and section heading | RULE DEFINED — full criteria text unavailable |
| CH-06 | Context overlap | Overlap occurs only inside a long section, not across role boundaries | PASS as a parsing requirement; production implementation not executed |
| CH-07 | Tokenizer-aware size enforcement | Chunk sizes measured with production tokenizer | NOT RUN — tokenizer/model not supplied |

## 6. Recommended configuration
Use **300-token target chunks with 40-token overlap as an initial default**, subject to actual tokenizer validation. More important than the numeric setting is the boundary strategy:

- Create one parent document per job listing.
- Split on Markdown headings before applying token limits.
- Keep a job title, department, employment type, work arrangement, location, posting/closing dates, and its criteria together when they fit.
- For long criteria sections, split only within the same job record; repeat the job title and subsection heading in each continuation.
- Keep each FAQ question and its complete answer together. Do not split between question and answer.
- Do not carry overlap from one job into the next job or from one FAQ into another.
- Store source URL, source owner, verification status, and `verified_at` as metadata rather than relying on duplicated prose.

## 7. Suggested chunk metadata

```json
{
  "document_id": "JOB-SWE-FULLSTACK-001",
  "chunk_id": "JOB-SWE-FULLSTACK-001-C01",
  "document_type": "job_listing",
  "department": "engineering",
  "position_category": "software_development",
  "position_title": "Senior Full-Stack Developer",
  "section_heading": "Role summary",
  "source_url": "https://www.xicteksystems.com/careers",
  "source_owner": null,
  "verification_status": "pending_hr",
  "reviewed_at": "2026-11-10",
  "verified_at": null,
  "chunk_index": 1,
  "chunking_profile": "careers_balanced_300_40"
}
```

## 8. Acceptance criteria for production retest
- 100% of job chunks contain exactly one `position_title`.
- 100% of FAQ chunks contain one complete question and its answer.
- 0 cross-role or cross-FAQ boundary contamination.
- 0 orphan headings without the relevant section content.
- Every continuation chunk repeats role title and section heading in its text or metadata.
- Every chunk retains source URL and verification status.
- No unverified or expired vacancy is indexed as active.
- Chunk size is measured using the actual production tokenizer; oversized sections are split deterministically.
- Retrieval spot checks return the correct job/FAQ and do not return adjacent role content.

## 9. Conclusion
The recommended approach is heading-aware, role-isolated chunking with a 300-token target and 40-token overlap as an initial profile. The current public source is too sparse to validate detailed job-criteria lists, and an approved FAQ corpus was not available. Treat this as a structural design/test report, not proof of production retrieval performance. Obtain approved HR content, run the parser with the actual tokenizer, and verify retrieval before marking the task complete.
