# Careers Domain Parsing & Chunking Checklist

## A. Source preparation
- [ ] Confirm source URL and canonical page.
- [ ] Confirm HR/hiring owner and approval reference.
- [ ] Confirm vacancy is active before indexing it as active.
- [ ] Capture posting date, closing date, location, employment type, and work arrangement where provided.
- [ ] Remove navigation, footer, repeated promotional boilerplate, duplicate apply prompts, and unrelated page chrome.
- [ ] Preserve meaningful eligibility, requirements, responsibilities, benefits, and application instructions.
- [ ] Do not invent missing qualifications, salary, dates, policy rules, or FAQ answers.
- [ ] Keep unverified content in staging; do not mix it into production retrieval.

## B. Markdown parsing
- [ ] Normalize heading levels (`#`, `##`, `###`) consistently.
- [ ] Start a new document at each job title.
- [ ] Keep each job title and its role metadata in the same parent document.
- [ ] Keep each FAQ question and answer as one atomic block.
- [ ] Keep bullet lists under their correct heading.
- [ ] Do not detach a list from the heading that explains it.
- [ ] Preserve list order and nested bullet hierarchy.
- [ ] Remove empty headings and duplicate headings.
- [ ] Detect malformed YAML front matter and invalid metadata types.

## C. Chunk construction
- [ ] Split on headings before applying token limits.
- [ ] Start with 300-token target and 40-token overlap; validate using production tokenizer.
- [ ] Do not split short role cards or FAQ pairs unnecessarily.
- [ ] If a long requirements list must split, repeat role title and subsection heading in each continuation.
- [ ] Apply overlap only within the same job or FAQ document.
- [ ] Never overlap text across two different jobs or FAQ records.
- [ ] Avoid orphan headings and dangling list bullets.
- [ ] Store chunk index, parent document ID, and chunking profile.
- [ ] Preserve source URL and verification metadata on every chunk.

## D. Metadata validation
- [ ] `document_id` is stable and unique.
- [ ] `chunk_id` is stable and unique.
- [ ] `document_type` is controlled vocabulary (`job_listing`, `career_faq`, `hiring_policy`, `internship_program`).
- [ ] `department` uses an approved controlled vocabulary.
- [ ] `position_category` uses an approved controlled vocabulary.
- [ ] `position_title` is present for job records.
- [ ] `source_url` is canonical and valid.
- [ ] `source_owner`, `verification_status`, `reviewed_at`, and `verified_at` are present where applicable.
- [ ] Unknown values are `null`, not guessed.
- [ ] Posting and closing dates use ISO `YYYY-MM-DD`.

## E. Quality assurance and retrieval
- [ ] Count source headings and parsed sections; investigate mismatches.
- [ ] Confirm every active source role has a matching parsed document.
- [ ] Confirm every parsed document maps back to a source URL.
- [ ] Check for duplicate chunks and repeated boilerplate.
- [ ] Check chunk lengths with the production tokenizer.
- [ ] Run retrieval queries for each job title and key skill.
- [ ] Run retrieval queries for each FAQ question and paraphrase.
- [ ] Confirm retrieved answer includes the right role/FAQ context.
- [ ] Confirm no adjacent role appears in the same result unless explicitly requested.
- [ ] Record precision/recall or pass/fail results from the actual retrieval test.
- [ ] Re-index only after HR approval and parser QA.

## F. Sign-off
- [ ] HR owner approves source content.
- [ ] Knowledge-base owner approves metadata taxonomy.
- [ ] Engineering confirms parser/tokenizer configuration.
- [ ] QA records test dataset, run date, and retrieval results.
- [ ] Production indexing approval recorded.

**Current status:** Checklist prepared. HR-approved FAQ corpus, detailed role criteria, and production tokenizer/retrieval environment were not available for this initial test.
