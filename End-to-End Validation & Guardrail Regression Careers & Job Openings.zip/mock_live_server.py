"""Local MOCK of the live assistant API shape (for testing the adapter only). ECHO=1 mimics the '(In response to: ...)' suffix."""
import json, os, re
from http.server import BaseHTTPRequestHandler, HTTPServer
ECHO = os.getenv("ECHO", "1") == "1"
class H(BaseHTTPRequestHandler):
    def do_POST(self):
        d = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        q = d["message"]
        assert "x-session-id" in {k.lower() for k in self.headers.keys()} and "conversationId" in d and "history" in d
        ans = "I don't have that in the current XICTEK knowledge base."
        if re.search(r"about|who is xictek|services", q, re.I): ans = "XICTEK Systems is a software company. Source: https://www.xicteksystems.com"
        if ECHO: ans += f' (In response to: "{q}")'
        b = json.dumps({"answer": ans}).encode()
        self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b)
    def log_message(self, *a): pass
HTTPServer(("127.0.0.1", 8765), H).serve_forever()
