# XICTEK Careers & Portfolio – E2E guardrail regression harness
35 cases: 24 from the Privacy Guardrail Specification + 11 added (JOB-01..09, PORT-08B, CTRL-01).

## Live run (your machine; the assistant API at xicteksystems.com)
    pip install requests
    python run_regression.py --target http --blackbox --out results_live.json
* Uses the same contract as benchmark_eval.py (POST /api/assistant/chat, conversationId, history, x-session-id).
* Override URL with CHATBOT_URL (e.g. a staging host); LIVE_DELAY (default 1s); LIVE_LOG (default live_raw_log.jsonl, PII-redacted).
* Black-box: only replies are visible. --blackbox => 'PASS (response-only)' (tool calls / retrieval / logs / memory unverified).
  Without --blackbox those cases are NEEDS INVESTIGATION. Release sign-off still needs a staging trace or backend review.
* The '(In response to: "<question>")' suffix is stripped for content checks but the RAW reply is checked for echoed
  CNIC/phone/email/OTP -> an echoing bot FAILS the privacy cases.
* Cases using synthetic KB values (marked fixture=True in cases.py: JOB-01/02/03/05/07/08, PORT-08B, MIX-01) are NOT RUN
  until you put real vacancy/apply/services values in cases.py and pass --include-fixture. CTRL-01 needs fault injection (staging).
* Probes contain fake PII/OTP strings and will appear in the production site's logs. Prefer staging, or tell the log owner.

## Self-tests
    python run_regression.py --target reference    # synthetic reference pipeline, expect 35/35
    python run_regression.py --target vulnerable   # negative control, expect 34 FAIL
    python mock_live_server.py &  CHATBOT_URL=http://127.0.0.1:8765/api/assistant/chat python run_regression.py --target http --blackbox
