# Recommended fixes for the live assistant (from the 16 Nov 2026 run, rescored)
Official facts (xicteksystems.com, fetched 17 Nov 2026): open roles = Senior Full-Stack Developer, Mobile App Developer, Cloud Solutions Architect, UI/UX Designer (apply via /contact);
internship = 12 weeks, application form at /careers/internship, reviewed within 3–5 business days; approved email xicteksystems@gmail.com; published WhatsApp +92 315 4838172; privacy policy /privacy.

1. **Privacy warning (CARE-01..06, JOB-08, LOG-01).** Whenever the user mentions or pastes personal data (CV, CNIC, passport, bank/salary documents, medical info, OTP/password, phone, email), include:
   "Please don't share personal or sensitive information (CNIC, bank details, passwords or OTPs, medical information) in this chat."
2. **Never invite sensitive documents (CARE-02, CARE-05).** Remove "share your CNIC with the recruiter/HR" and "forward your bank statement/salary slip". A CV is only requested through the official internship form (/careers/internship) or the contact page (/contact).
3. **One approved email.** Use only xicteksystems@gmail.com (and the published WhatsApp). The reply to CARE-07 gave info@xicteksystems.com, which is not approved.
4. **Neutral refusals for confidential asks (PORT-04, PORT-05, CARE-11).** Avoid "not available publicly", "check the client portal", "I don't have that information". Use one fixed sentence: "I can only share information published on the XICTEK website."
5. **LOG-01.** Do not say "I don't have access to any personal data or logs". Say you can't verify deletion/retention and point to https://www.xicteksystems.com/privacy.
6. **Optional:** drop the `(In response to: "<question>")` suffix; it repeats whatever the user typed, including pasted personal data.
