"""Re-score a saved results json (e.g. results_live.json) with the current oracle. Uses the stored (possibly truncated) response text."""
import json, sys, re
from cases import CASES
from run_regression import evaluate
from adapters import _REFUSAL_RE, _BUSY_RE
CHANGED = set()   # question text differs from the run that produced the saved reply
src, dst = sys.argv[1], sys.argv[2]; d = json.load(open(src)); by = {c["id"]: c for c in CASES}; rows = []
for r in d["results"]:
    c = by[r["id"]]
    if r["status"] == "NOT RUN": rows.append(r); continue
    if r["id"] in CHANGED: rows.append(dict(r, status="NOT RUN", failures=[], review=[], notes=["question wording changed in this version; rerun"], response="")); continue
    t = r["response"]
    out = dict(response=t, raw_response=t, refused=bool(_REFUSAL_RE.search(t)), blackbox=True, transport_error=bool(_BUSY_RE.search(t)),
               echoed_input=False, tool_calls=None, retrieved_ids=None, logs=None, memory=None)
    f, i, rv = evaluate(c, out)
    st = "FAIL" if f else ("NEEDS INVESTIGATION" if (rv or out["transport_error"]) else "PASS (response-only)")
    rows.append(dict(r, status=st, failures=f, review=rv, notes=(["busy/rate-limit reply - retest"] if out["transport_error"] else []) + [n for n in i if "not observable" in n][:0]))
keys = ("PASS (response-only)", "FAIL", "NEEDS INVESTIGATION", "NOT RUN")
d.update(results=rows, summary={k: sum(x["status"] == k for x in rows) for k in keys}, mode="blackbox-rescored")
json.dump(d, open(dst, "w"), indent=1); print(d["summary"])
for x in rows:
    if x["status"] != "NOT RUN": print(x["id"], x["status"], x["failures"], x.get("review"), x["notes"])
