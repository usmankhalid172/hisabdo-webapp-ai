#!/usr/bin/env python3
"""Vacancy register validator + live-page diff.
  python vacancy_check.py vacancies.json                     # schema + safety rules only
  python vacancy_check.py vacancies.json --live              # also fetch https://www.xicteksystems.com/careers (needs requests)
  python vacancy_check.py vacancies.json --html page.html    # compare with a saved copy of the page (HTML or markdown)
Exit 0 = register valid and matches the page; 1 = errors."""
import argparse, datetime, json, re, sys
URL = "https://www.xicteksystems.com/careers"
STATUSES = {"open", "closed", "draft"}
REQ = ["id", "title", "status", "public_release", "source_url", "apply_route", "deadline", "salary", "owner", "reviewed", "approved_by"]
EMAIL = re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+"); PHONE = re.compile(r"(?<!\d)(?:\+?92|0)?3\d{2}[- ]?\d{7}(?!\d)")

def page_titles(text):
    m = re.search(r"Current Openings(.*?)(Student or Recent Graduate|$)", text, re.S | re.I)
    seg = m.group(1) if m else text
    t = re.findall(r"<h3[^>]*>(.*?)</h3>", seg, re.S | re.I) or re.findall(r"^###\s+(.+)$", seg, re.M)
    return [re.sub(r"<[^>]+>", "", x).strip() for x in t if x.strip()]

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("register"); ap.add_argument("--live", action="store_true")
    ap.add_argument("--html"); ap.add_argument("--today", default=str(datetime.date.today())); a = ap.parse_args()
    reg = json.load(open(a.register)); approved = reg["approved_contact_email"].lower(); today = datetime.date.fromisoformat(a.today)
    errs, warns, ids = [], [], set()
    for v in reg["vacancies"]:
        vid = v.get("id", "?")
        miss = [k for k in REQ if k not in v]
        if miss: errs.append(f"{vid}: missing fields {miss}"); continue
        if vid in ids: errs.append(f"{vid}: duplicate id")
        ids.add(vid)
        if v["status"] not in STATUSES: errs.append(f"{vid}: status must be one of {sorted(STATUSES)}")
        if v["status"] == "open" and not v["public_release"]: errs.append(f"{vid}: open role must be public_release=true")
        if v["status"] != "open" and v["public_release"]: errs.append(f"{vid}: {v['status']} role must be public_release=false (closed/draft never listed as open)")
        if v["public_release"] and not v["source_url"].startswith("https://www.xicteksystems.com/"): errs.append(f"{vid}: public role needs an xicteksystems.com source_url")
        if v["public_release"] and not v["approved_by"]: errs.append(f"{vid}: public role needs approved_by")
        if v["deadline"] or v["salary"]:
            if not v.get("deadline_salary_source"): errs.append(f"{vid}: deadline/salary only if published (add deadline_salary_source URL)")
        for k, val in v.items():
            s = json.dumps(val)
            for em in EMAIL.findall(s):
                if em.lower() != approved: errs.append(f"{vid}.{k}: unapproved email {em}")
            if PHONE.search(s): errs.append(f"{vid}.{k}: phone number not allowed in vacancy record")
        try:
            age = (today - datetime.date.fromisoformat(v["reviewed"])).days
            if age > 30: warns.append(f"{vid}: last reviewed {age} days ago (review at least every 30 days)")
        except ValueError: errs.append(f"{vid}: reviewed must be YYYY-MM-DD")
    page = None
    if a.html: page = open(a.html, encoding="utf-8").read()
    elif a.live:
        import requests; page = requests.get(URL, timeout=30, headers={"user-agent": "Mozilla/5.0"}).text
    if page is not None:
        live = set(page_titles(page)); reg_open = {v["title"] for v in reg["vacancies"] if v["status"] == "open" and v["public_release"]}
        reg_hidden = {v["title"] for v in reg["vacancies"] if not v["public_release"]}
        if not live: errs.append("could not parse any roles from the page (page layout changed? check parser)")
        for t in sorted(live - reg_open): errs.append(f"ON PAGE but not an open public role in register: {t}")
        for t in sorted(reg_open - live): errs.append(f"OPEN in register but NOT on page: {t}")
        for t in sorted(reg_hidden & live): errs.append(f"DRAFT/CLOSED role visible on page: {t}")
    for w in warns: print("WARN ", w)
    for e in errs: print("ERROR", e)
    print("RESULT:", "FAIL" if errs else "PASS", f"({len(reg['vacancies'])} records, {len(errs)} errors, {len(warns)} warnings)")
    sys.exit(1 if errs else 0)
main()
