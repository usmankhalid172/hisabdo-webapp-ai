# XICTEK Corporate Knowledge Set: Cleaning Deliverable

## Files
- `cleaned_corporate_knowledge.jsonl`: curated records suitable for chunking/ingestion into a RAG knowledge base.
- `metadata_schema.yaml`: required metadata fields, controlled `service_vertical` vocabulary, and validation rules.
- `metadata_validation_log.csv`: source-by-source cleanup and metadata QA log.

## Cleaning applied
- Removed navigation/menu and generic repeated page chrome from curated content.
- Consolidated page copy into concise, retrieval-oriented corporate and service records.
- Kept source URLs and page labels on each record.
- Applied mandatory controlled-vocabulary `service_vertical` metadata.
- Avoided adding unverified metrics, certifications, customer claims, prices, guarantees, or project-specific commitments.
- Qualified catalog capabilities as examples where necessary.

## Validation
The records were checked for unique IDs, required metadata, controlled vertical tags, HTTPS source references, and content-status values. Validation log statuses indicate a public website content review, not formal owner sign-off.

## Important handover note
These records are based on publicly accessible XICTEK Systems pages reviewed on 2026-11-09. Before production ingestion, a content owner should confirm company facts and current service availability. Use `approved_with_claim_limits` as the chatbot instruction to avoid treating a service catalog as a universal delivery promise.

## Sources
- https://www.xicteksystems.com/
- https://www.xicteksystems.com/about
- https://www.xicteksystems.com/services
- https://www.xicteksystems.com/services/custom-software-development
- https://www.xicteksystems.com/services/web-development
- https://www.xicteksystems.com/services/ai-solutions
- https://www.xicteksystems.com/services/cloud-solutions
