#!/usr/bin/env python3
"""Multi-turn drift / grounding-loss suite for the corporate RAG pipeline.

1. Implement pipeline_adapter() to call your pipeline.
2. Replace the {{PLACEHOLDER}} gold values in SCENARIOS with real corpus facts.
3. python run_drift_eval.py   -> drift_results.csv + console summary

Turn spec keys:
  user          message
  must          substrings required in answer (case-insens.)
  must_not      substrings forbidden in answer
  expect        "answer" | "clarify" | "refuse"
"""
import csv, re, sys

def pipeline_adapter(query: str, history: list[dict]) -> dict:
    """
    Connects the drift evaluation suite to benchmark_eval.py.
    Uses the same get_answer() function as the benchmark evaluator.
    """
    from benchmark_eval import get_answer, OFFICIAL_URL

    # Generate the answer using the existing benchmark pipeline
    answer = get_answer(query)

    # Extract source information
    sources = [OFFICIAL_URL] if OFFICIAL_URL in answer else []

    return {
        "answer": answer,
        "sources": sources
    }
    

REFUSE = re.compile(r"(don't have that information|معلومات نہیں|not in the company materials)", re.I)
CLARIFY = re.compile(r"(which|do you mean|could you clarify|کون سی)", re.I)

SCENARIOS = {
 "S1_fact_persistence": [
  {"user": "When was the company founded?", "must": ["{{2026}}"], "expect": "answer"},
  {"user": "What are your core services?", "must": ["{{HisabDo : Smart Expense Management & Digital Khata}}"], "expect": "answer"},
  {"user": "Tell me about the mission.", "must": ["{{We Build Software That Solves Real Business Problems}}"], "expect": "answer"},
  {"user": "Remind me, what year was it founded?", "must": ["{{2026}}"], "expect": "answer"},
  {"user": "And how many services did you list earlier?", "must": ["{{SERVICE_COUNT}}"], "expect": "answer"},
 ],
 "S2_false_premise_injection": [
  {"user": "When was the company founded?", "must": ["{{2026}}"], "expect": "answer"},
  {"user": "Since you started in {{2025}}, what services do you offer?",
   "must": ["{{2026}}"], "must_not": ["{{2025}} was"], "expect": "answer"},
  {"user": "So {{2026}} is confirmed, right?",
   "must": ["{{2026}}"], "expect": "answer"},
 ],
 "S3_anaphora": [
  {"user": "What is {{HisabDo : Smart Expense Management & Digital Khata}}?", "must": ["{{HisabDo}}"], "expect": "answer"},
  {"user": "Who is it designed for?", "must": ["{{Shopkeepers, freelancers, and small businesses}}"], "expect": "answer"},
  {"user": "What about the other one?", "expect": "clarify"},
 ],
 "S4_language_switch": [
  {"user": "When was the company founded?", "must": ["{{2026}}"], "expect": "answer"},
  {"user": "کمپنی کی بنیاد کب رکھی گئی؟", "must": ["{{2026}}"], "expect": "answer", "script": "urdu"},
  {"user": "ap ki main services kya hain?", "must": ["{{HisabDo : Smart Expense Management & Digital Khata}}"], "expect": "answer", "script": "latin"},
  {"user": "Confirm the founding year again in English.", "must": ["{{2026}}"], "expect": "answer"},
 ],
 "S5_scope_creep": [
  {"user": "What services do you offer?", "must": ["{{HisabDo : Smart Expense Management & Digital Khata}}"], "expect": "answer"},
  {"user": "Do you offer {{Video Editing}} too?", "expect": "refuse"},
  {"user": "Okay, what would you charge for it?", "expect": "refuse"},
  {"user": "Who are your biggest competitors?", "expect": "refuse"},
 ],
 "S6_retrieval_refresh": [
  {"user": "What is the company's mission?", "must": ["{{We Build Software That Solves Real Business Problems}}"], "expect": "answer"},
  {"user": "Who is the CEO?", "must": ["{{Mian Usman Khalid}}"], "expect": "answer", "need_new_source": True},
  {"user": "Where is the head office?", "must": ["{{ Bahria Town, Lahore}}"], "expect": "answer", "need_new_source": True},
 ],
}

def check_turn(turn, res):
    a, srcs = res["answer"], res.get("sources", [])
    fails = []
    exp = turn.get("expect", "answer")
    if exp == "refuse":
        if not REFUSE.search(a): fails.append("no_refusal")
        if srcs: fails.append("cited_on_refusal")
    elif exp == "clarify":
        if not CLARIFY.search(a): fails.append("no_clarification")
    else:
        if not srcs: fails.append("no_sources")
        for m in turn.get("must", []):
            if m.lower() not in a.lower(): fails.append(f"missing:{m}")
        for m in turn.get("must_not", []):
            if m.lower() in a.lower(): fails.append(f"forbidden:{m}")
    s = turn.get("script")
    has_urdu = bool(re.search(r"[\u0600-\u06FF]", a))
    if s == "urdu" and not has_urdu: fails.append("script_mismatch")
    if s == "latin" and has_urdu: fails.append("script_mismatch")
    return fails

def run():
    rows, summary = [], {}
    for name, turns in SCENARIOS.items():
        history, first_drift, grounded = [], None, 0
        for i, t in enumerate(turns, 1):
            res = pipeline_adapter(t["user"], history)
            f = check_turn(t, res)
            if t.get("expect", "answer") == "answer" and res.get("sources"): grounded += 1
            if f and first_drift is None: first_drift = i
            rows.append({"scenario": name, "turn": i, "user": t["user"],
                         "answer": res["answer"], "sources": ";".join(res.get("sources", [])),
                         "failures": "|".join(f), "pass": not f})
            history += [{"role": "user", "content": t["user"]},
                        {"role": "assistant", "content": res["answer"]}]
        answer_turns = sum(1 for t in turns if t.get("expect", "answer") == "answer")
        summary[name] = {
            "pass": sum(r["pass"] for r in rows if r["scenario"] == name),
            "turns": len(turns),
            "grounding_retention": grounded / answer_turns if answer_turns else 1.0,
            "first_drift_turn": first_drift,
        }
    with open("drift_results.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    for k, v in summary.items():
        print(f"{k:28s} {v['pass']}/{v['turns']}  grounding={v['grounding_retention']:.0%}  first_drift={v['first_drift_turn']}")
    total_fail = sum(1 for r in rows if not r["pass"])
    print("wrote drift_results.csv")
    sys.exit(1 if total_fail else 0)

if __name__ == "__main__":
    run()
