#!/usr/bin/env python3
"""Triage failed rows in results_eval.csv into root-cause buckets.

Usage: python triage_failures.py results_eval.csv
Column names differ across harnesses; edit COLS if yours differ.
Heuristic buckets are a first pass: confirm by reading each row.
"""
import csv, re, sys
from collections import Counter

COLS = {
    "id": ["id", "qid", "question_id"],
    "type": ["type", "question_type", "category"],
    "question": ["question", "query", "prompt"],
    "answer": ["answer", "response", "output"],
    "expected": ["expected_any_of", "expected", "gold", "reference", "expected_answer"],
    "should_answer": ["should_answer"],
    "accuracy": ["accuracy", "acc", "correct"],
    "sources": ["sources", "source", "citations"],
    "context": ["context", "retrieved", "chunks"],
}
URDU = re.compile(r"[\u0600-\u06FF]")
CLARIFY = re.compile(r"(which|do you mean|could you clarify|کون سی|کیا آپ)", re.I)
REFUSE = re.compile(r"(don't have that information|do not have|not available|معلومات نہیں)", re.I)

def pick(row, key):
    for name in COLS[key]:
        for k in row:
            if k.lower() == name:
                return row[k]
    return ""

def passed(v):
    return str(v).strip().lower() in {"1", "true", "pass", "yes", "1.0"}

def tokens(s):
    return set(re.findall(r"\w+", s.lower()))

FALLBACK = re.compile(r"(could not find that information|i don't have that information|معلومات نہیں)", re.I)

def expected_terms(s):
    """expected_any_of may be 'a|b', 'a;b', 'a,b' or a JSON-style list."""
    s = s.strip().strip("[]")
    parts = re.split(r"[|;]|\s*,\s*(?=['\"]?\w)", s)
    return [p.strip().strip("'\"") for p in parts if p.strip().strip("'\"")]

def bucket(r):
    t, q, a = r["type"], r["question"], r["answer"]
    exp = r["expected"]
    sa = str(r["should_answer"]).strip().lower()
    should_answer = sa in {"1", "true", "yes", "1.0"} if sa else t != "out_of_scope"
    is_fallback = bool(FALLBACK.search(a))
    hit = any(x.lower() in a.lower() for x in expected_terms(exp)) if exp else None

    if not should_answer:
        return "SHOULD_REFUSE" if not is_fallback else "UNKNOWN (refused but still failed: check judge)"
    if t == "ambiguous" and not CLARIFY.search(a):
        return "SHOULD_CLARIFY"
    if URDU.search(q) and not URDU.search(a):
        return "LANGUAGE_MISMATCH" if not is_fallback else "RETRIEVAL_MISS (+LANGUAGE_MISMATCH)"
    if is_fallback:
        return "RETRIEVAL_MISS (or corpus gap: check expected_any_of against the source page)"
    if hit is False:
        return "GENERATION_UNFAITHFUL (answered, no expected term present)"
    if re.search(r"[A-Za-z]", q) and not URDU.search(q) and re.search(r"\b(kis|ka|ki|batao|kya|hai)\b", q, re.I) \
            and not re.search(r"\b(kis|ka|ki|hai|hain|aap|hum)\b", a, re.I):
        return "LANGUAGE_MISMATCH (Roman Urdu query, English answer)"
    return "UNKNOWN (inspect manually)"

def main(path):
    rows = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        for raw in csv.DictReader(f):
            rows.append({k: pick(raw, k) for k in COLS})
    fails = [r for r in rows if not passed(r["accuracy"])]
    out = []
    for r in fails:
        r["bucket"] = bucket(r)
        out.append(r)
    with open("failure_triage.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["id", "type", "bucket", "question", "answer", "expected"],
                           extrasaction="ignore")
        w.writeheader(); w.writerows(out)
    print(f"{len(fails)}/{len(rows)} failed")
    for k, v in Counter(r["bucket"] for r in out).most_common():
        print(f"  {k:55s} {v}")
    for r in out:
        print(f"  {r['id']:5s} {r['type']:13s} {r['bucket']}")
    print("wrote failure_triage.csv")

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "results_eval.csv")
