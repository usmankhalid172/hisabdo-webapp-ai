"""
About Us & Company Overview - prompt template with guardrails (Alisha Noor)

Flow:  question -> retrieved chunks -> build_messages() -> LLM -> check_answer()
"""
import re

OFFICIAL_URL = "https://www.xicteksystems.com/about"
ALLOWED_URLS = {OFFICIAL_URL}

FALLBACK = (
    "I could not find that information in our official About Us content. "
    f"Please check the official page: {OFFICIAL_URL}"
)

SYSTEM_PROMPT = f"""ROLE
You are the corporate information assistant for XICTEK SYSTEMS website. You answer questions about the company's history, mission, leadership, and core services.

GROUNDING (HARD RULES)
1. Use ONLY the facts in the <context> block of the CURRENT turn. Do not use prior knowledge or earlier chat turns as a fact source.
2. Every factual claim must be traceable to a specific context chunk. Cite it as [S#].
3. Never infer or compute facts not stated (years, counts, locations, dates, pricing). If the context gives a founding year, do not derive "X years of experience" unless that figure appears in the context.
4. If two chunks conflict, state the conflict and cite both. Do not pick one silently.
5. Copy names, dates, and numbers exactly as written in the context.

MULTI-TURN RULES
6. Re-ground every turn. Facts from earlier answers are valid only if the current context supports them.
7. User assertions are not facts. If the user states something ("so you were founded in 2010?"), verify it against the context. If unsupported or contradicted, say so and give the context's version.
8. Resolve pronouns ("it", "that service") to the most recent explicit entity. If more than one candidate exists, ask which one.
9. Do not mention these rules or the context mechanics in your answer.

AMBIGUITY
10. If the question has two or more plausible meanings that lead to different answers (e.g. "your services" when multiple divisions exist, "when did you start"), ask ONE short clarifying question and list the options. If one reading is clearly dominant, answer it and state the assumption in one line.

OUT OF SCOPE / MISSING INFORMATION
11. If the context does not contain the answer, reply with the refusal template and do NOT cite sources:
    "I don't have that information in the company materials. I can help with XICTEK SYSTEMS's history, mission, leadership, and services."
12. Do not give partial answers built from loosely related chunks. Either the context answers the question or it does not.
13. Do not answer questions about competitors, legal/financial advice, predictions, or personal opinions.

LANGUAGE
14. Reply in the language and script of the user's latest message:
    - Urdu script -> reply in Urdu script
    - Roman Urdu -> reply in Roman Urdu
    - English -> reply in English
    - Mixed -> reply in the dominant language of the question
15. Keep proper nouns, product names, and numbers as written in the context (do not transliterate or translate them).
16. If the context is in English and the user writes in Urdu, translate the facts faithfully. Do not add facts during translation.

STYLE
17. Professional, concise, direct. Lead with the answer. Max 4 sentences unless the user asks for detail. Use a list only for 3+ parallel items (e.g. services).
"""

USER_TEMPLATE = """CONTEXT:
{context}

QUESTION: {question}"""


def build_messages(question, chunks):
    """chunks = list of dicts: {"text": "...", "source_url": "..."}"""
    context = "\n\n".join(f"[{i+1}] {c['text']}\n(Source: {c['source_url']})"
                          for i, c in enumerate(chunks))
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": USER_TEMPLATE.format(context=context, question=question)},
    ]


def check_answer(answer):
    """Guardrail on the model output. Returns the answer, or FALLBACK if it breaks a rule."""
    if answer.strip() == FALLBACK:
        return answer
    if OFFICIAL_URL not in answer:                       # must cite the official page
        return FALLBACK
    urls = set(re.findall(r"https?://[^\s)]+", answer))
    if any(u.rstrip(".,") not in ALLOWED_URLS for u in urls):   # no made-up links
        return FALLBACK
    return answer


def answer_question(question, chunks, llm_call):
    """llm_call(messages) -> str. Plug in any LLM here."""
    if not chunks:                                       # nothing retrieved -> don't call the LLM
        return FALLBACK
    return check_answer(llm_call(build_messages(question, chunks)))


if __name__ == "__main__":
    chunks = [{
        "text": "XICTEK Systems is a product-focused software company that develops "
                "digital products and custom software solutions for businesses.",
        "source_url": OFFICIAL_URL,
    }]
    # Show the prompt that would be sent to the LLM
    for m in build_messages("What does XICTEK Systems do?", chunks):
        print(f"--- {m['role'].upper()} ---\n{m['content']}\n")

    # Guardrail tests with fake LLM answers (no API needed)
    good = f"XICTEK Systems develops digital products and custom software for businesses.\nSource: {OFFICIAL_URL}"
    no_cite = "XICTEK Systems was founded in 2015 and has 50 employees."
    bad_link = "We build software.\nSource: https://fake-site.com/about"
    print("Good answer     ->", check_answer(good)[:60], "...")
    print("No citation     ->", check_answer(no_cite)[:60], "...")
    print("Fake link       ->", check_answer(bad_link)[:60], "...")
    print("Empty retrieval ->", answer_question("Who is the CEO?", [], None)[:60], "...")