# E2E Evaluation Log: Corporate Domain (About Us & Core Services)

| Field | Value |
|---|---|
| Date | 2026-10-30 |
| Scope | About Us / corporate history / core services prompts |
| Pipeline | Full RAG (retrieve -> rerank -> generate -> cite) |
| Dataset | 22 questions (simple 6, ambiguous 5, mixed_urdu 6, out_of_scope 5) |
| Artifact | `results_eval.csv` |
| Status | **FAIL** (overall 15/22 = 68.2%, below gate) |

## 1. Results

| Metric | Score | Rate |
|---|---|---|
| accuracy | 15/22 | 68.2% |
| tone | 22/22 | 100% |
| source | 22/22 | 100% |
| overall | 15/22 | 68.2% |

`overall` equals `accuracy` exactly. Tone and source never gate the outcome.

| Type | Pass | Rate | Failures |
|---|---|---|---|
| simple | 5/6 | 83.3% | 1 |
| out_of_scope | 4/5 | 80.0% | 1 |
| ambiguous | 3/5 | 60.0% | 2 |
| mixed_urdu | 3/6 | 50.0% | 3 |

Failed IDs: `Q02, Q10, Q11, Q15, Q16, Q17, Q18` (7 total; type counts reconcile: 1+1+2+3 = 7).

## 2. Findings (supported by the data)

**F1. Failures are accuracy failures, not format failures.** Tone and source are 22/22 while accuracy is 15/22. The failing answers are well-formed and cited but wrong or incomplete. This is a grounded-but-incorrect pattern, which points at retrieval selection or generation faithfulness, not style.

**F2. mixed_urdu is the weakest segment (50%).** It carries 3 of 7 failures with only 6 of 22 questions. Likely cause is cross-lingual retrieval or answer-language handling. This is the top fix priority.

**F3. ambiguous is second weakest (60%).** Two of five fail. Whether the model should have asked a clarifying question or answered with an assumption is unspecified in the current prompt.

**F4. Metric validity concern: `source` = 22/22.** This includes the 5 out_of_scope items. If out_of_scope answers are *supposed* to refuse, a perfect source score means either the metric only checks "citation field is non-empty" or the model cites chunks while refusing. Either way, `source` is not discriminating. Treat it as non-informative until redefined (see Section 5).

**F5. Single-turn only.** This run does not measure multi-turn drift. The objective requires it. See `run_drift_eval.py`.

## 3. Triage Results (from `failure_triage.csv`, 7 failures)

Source of evidence: question + answer text only. The `expected` and `context` columns in the CSV are empty, so retrieval-vs-corpus-gap calls are inferred, not verified. Confidence column reflects that.

### 3.1 Bucket per failed ID

| ID | Type | Question | Primary bucket | Secondary | Conf. | Evidence |
|---|---|---|---|---|---|---|
| Q02 | simple | What is the company tagline? | RETRIEVAL_MISS | n/a | med | Fallback; same as Q16, so not a language issue. Could also be a corpus gap (see 3.3) |
| Q10 | ambiguous | What is your experience? | SHOULD_CLARIFY | n/a | high | Multiple readings; got generic fallback instead of a clarifying question |
| Q11 | ambiguous | Are you the best software company? | GENERATION_UNFAITHFUL | n/a | high | Dumped the Approach & Methodology chunk; never addressed the superlative |
| Q15 | mixed_urdu | HisabDo kis ne banaya? | LANGUAGE_MISMATCH | FORMAT_LEAK | high | Correct fact (XICTEK Systems), but English answer to Roman Urdu; heading leaked |
| Q16 | mixed_urdu | Company ka tagline batao | RETRIEVAL_MISS | LANGUAGE_MISMATCH | med | Roman Urdu twin of Q02; same fallback, English reply |
| Q17 | mixed_urdu | آپ کی کمپنی کیا کام کرتی ہے؟ | RETRIEVAL_MISS | LANGUAGE_MISMATCH | med | Fallback on content the corpus demonstrably contains; English reply to Urdu script |
| Q18 | out_of_scope | When was the company founded? | SHOULD_REFUSE | FORMAT_LEAK | high | No founding date in corpus; answered with Leadership chunk instead of refusing |

### 3.2 Bucket totals

| Bucket | Count | IDs |
|---|---|---|
| RETRIEVAL_MISS | 3 | Q02, Q16, Q17 |
| LANGUAGE_MISMATCH | 1 primary, 3 secondary | Q15 (primary); Q16, Q17 (secondary) |
| SHOULD_CLARIFY | 1 | Q10 |
| GENERATION_UNFAITHFUL | 1 | Q11 |
| SHOULD_REFUSE | 1 | Q18 |
| FORMAT_LEAK (secondary) | 2 | Q15, Q18 |

Reconciles with the eval: 7 failures = 3 + 1 + 1 + 1 + 1.

### 3.3 Hypothesis status

| ID | Hypothesis | Status | Evidence |
|---|---|---|---|
| H1 | Urdu/Roman-Urdu queries retrieve poorly | **Partially supported** | Q17 (Urdu script) fell back on content present in the corpus. Q15 retrieved fine in Roman Urdu, so it is not universal. Q16 is confounded with Q02 |
| H2 | Answer language does not match query language | **Supported** | All 3 mixed_urdu failures (Q15, Q16, Q17) were answered in English. The fallback string is hard-coded English |
| H3 | Corporate-history answers built from adjacent chunks | **Not supported as stated** | The simple failure (Q02) is a not-found, not a wrong-chunk answer. The adjacent-chunk pattern appears instead in Q18 (see H5) |
| H4 | Ambiguous queries get a confident answer instead of clarification | **Partially supported** | Q10 got a non-answer (not a confident one). Q11 got an off-target dump. Neither clarified or deflected |
| H5 | Out-of-scope gets a soft hallucination from a loosely related chunk | **Supported** | Q18: Leadership chunk returned for a founding-date question |

### 3.4 Cross-cutting observations

1. **Hard-coded English fallback.** Q02, Q10, Q16, Q17 all return the same English "I could not find..." string. It is language-blind, has no clarification path, and cannot distinguish "not in corpus" from "ambiguous".
2. **Raw chunk headings leak into answers** ("Leadership", "Products & Case Studies", "Approach & Methodology"). Strip section headings at ingestion or in post-processing.
3. **`source` metric is trivially satisfied.** Every answer, including refusals and fallbacks, ends with the same single URL (`https://www.xicteksystems.com/about`). This confirms finding F4: 22/22 on `source` carries no signal.
4. **The corpus appears to be one page.** Single-URL grounding means chunk-level IDs (S1, S2...) are needed for claim-level citation checks.
5. **No founding date in the corpus (Q18 is typed out_of_scope).** My earlier prompt examples and `run_drift_eval.py` assume a founding year is answerable. See 3.5.
6. **Tagline status unknown.** Q02 and Q16 are both expected to be answerable in the dataset, but nothing in the failed answers shows a tagline exists in the corpus. If it does not, these two are mislabeled in the gold set, not model failures. Check the About page text.

### 3.5 Required corrections to earlier deliverables

| File | Issue | Correction |
|---|---|---|
| `run_drift_eval.py` | S1, S2, S4 use `{{FOUNDING_YEAR}}`; the corpus has no founding date | Use facts the corpus does contain, e.g. founder/CEO (Mian Usman Khalid), HisabDo as a XICTEK product. Use founding year only as a *refusal* probe |
| `system_prompt_v2.txt` | Rule 11 refusal is English-only; the examples reference founding year | Make the refusal template language-aware (rule 14); add a rule: never output raw section headings |
| `PROMPT_OPTIMIZATION_FIXES.md` | Before/after example for C1 uses founding year | Swap to the founder or product facts |

These corrections are not applied yet.

## 4. Triage Procedure

```bash
python triage_failures.py results_eval.csv
# outputs: failure_triage.csv + console summary
```

Per failed ID, record: failure bucket, retrieved chunk IDs, whether the gold fact was in the top-k, and whether the answer asserts anything not present in the chunks. Bucket meanings:

| Bucket | Meaning | Fix layer |
|---|---|---|
| RETRIEVAL_MISS | Gold fact not in retrieved context | Retriever / query rewrite |
| GENERATION_UNFAITHFUL | Gold fact present, answer wrong or adds unsupported claims | Prompt |
| LANGUAGE_MISMATCH | Answer language/script differs from query | Prompt |
| SHOULD_CLARIFY | Ambiguous query answered without clarification | Prompt |
| SHOULD_REFUSE | Out-of-scope answered instead of refused | Prompt |

## 5. Fixes (see `PROMPT_OPTIMIZATION_FIXES.md`)

1. Prompt v2 with strict grounding, per-language rules, clarify-vs-assume policy, and a refusal template.
2. Query normalization for Urdu/Roman-Urdu before retrieval (retriever-side, not prompt-side).
3. Redefine `source` as a claim-level check: every factual sentence maps to a retrieved chunk. For out_of_scope items, pass = refusal with no citation.
4. Split `overall` into `accuracy AND grounded AND correct_behavior` so it differs from accuracy.

## 6. Multi-turn Drift Protocol

Run `python run_drift_eval.py` after wiring `pipeline_adapter()`. Scenarios cover:

| Scenario | Failure mode tested |
|---|---|
| S1 fact_persistence | Fact stated in turn 1 changes by turn 5 |
| S2 false_premise_injection | User asserts a wrong fact; model adopts it |
| S3 anaphora | "it", "that service", "they" resolve to the wrong entity |
| S4 language_switch | English -> Urdu -> English mid-dialog; facts stay consistent |
| S5 scope_creep | Gradual drift from corporate topics into unsupported claims |
| S6 retrieval_refresh | Follow-up still re-retrieves; does not answer from chat history alone |

Metrics per scenario: `fact_consistency`, `grounding_retention` (turns with valid citations / turns), `refusal_correctness`, `first_drift_turn`.

## 7. Exit Criteria

| Gate | Threshold |
|---|---|
| accuracy (all) | >= 90% |
| mixed_urdu accuracy | >= 85% |
| ambiguous accuracy | >= 85% |
| out_of_scope refusal | 100% |
| drift suite: fact_consistency | 100% |
| drift suite: grounding_retention | >= 95% |
| re-run on the same 22 + at least 20 new held-out questions | no regression |

Caution: 22 items is a small sample (one question = 4.5 pts). Tuning against the failed IDs risks overfitting, so keep a held-out set.

## 8. Next Actions

- [x] Run `triage_failures.py`, fill bucket per failed ID (done, see Section 3)
- [ ] Verify Q02/Q16: does the About page contain a tagline? (decides model failure vs gold-label error)
- [ ] Apply the corrections in 3.5 to the drift suite and prompt v2
- [ ] Apply prompt v2, re-run the 22, diff against `results_eval.csv`
- [ ] Wire `pipeline_adapter()`, run drift suite
- [ ] Add held-out questions (Urdu, Roman-Urdu, ambiguous)
- [ ] Fix metric definitions (Section 5)
