# HisabDo Grounded Generation & Citation Accuracy Package

Files:
- `grounded_generation_checklist.md` — retrieval, claim, link and release rules.
- `citation_audit_log.md` — official source register, claim audit, risks and audit outcome.
- `sample_response_transcripts.md` — target answer transcripts, including abstention and risk cases.
- `source_register.json` — machine-readable allowlist and review status.

Audit date: 2026-11-12.

Important: This is a public website content audit and proposed chatbot QA standard. It is not a code review, legal/privacy assessment, security test, or confirmation that the deployed chatbot currently follows these rules. High-risk claims are explicitly marked for product-owner confirmation.
