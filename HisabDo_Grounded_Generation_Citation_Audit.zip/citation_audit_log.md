# HisabDo Website References — Citation Audit Log

**Audit date:** 2026-11-12  
**Review type:** Public-source and link-grounding review  
**Interpretation:** “Reviewed” means the public page content was inspected. It does not mean the underlying app behavior was independently tested or approved by product/engineering.

## A. Approved public URL register

| ID | Official URL | Intended use | Review status |
|---|---|---|---|
| HD-01 | https://hisabdo.app/ | General product overview; broad capabilities | Reviewed; keep claims broad |
| HD-02 | https://hisabdo.app/about | Product purpose, audiences, high-level feature scope | Reviewed |
| HD-03 | https://hisabdo.app/about-app | Local records, optional sync, backup distinction, use cases | Reviewed |
| HD-04 | https://hisabdo.app/faq | FAQ-level feature explanations | Reviewed; detailed technical claims need owner validation |
| HD-05 | https://hisabdo.app/blog | Blog index/navigation only; use a specific article URL for article claims | Reviewed |
| HD-06 | https://hisabdo.app/company | XICTEK–HisabDo company relationship and company-level information | Reviewed |
| CX-01 | https://www.xicteksystems.com/ | Corporate-level confirmation that HisabDo is an XICTEK product | Reviewed; not a feature evidence source |

**Link allowlist rule:** Feature answers should link only to HD-01 through HD-05, choosing the most relevant page. HD-06 or CX-01 is permitted only for company relationship questions. Do not cite CX-01 as evidence for detailed app behavior.

## B. Claim audit

| Claim area | Public evidence observed | Grounding decision | Notes / follow-up |
|---|---|---|---|
| Product purpose | Overview and About describe an offline-first khata/ledger and expense-management app for shopkeepers, freelancers and small businesses. | APPROVED — broad wording | Use HD-01 or HD-02. |
| Customer records | Overview/About describe customer management, balances and customer history. FAQ gives more detailed customer-account workflow. | APPROVED — broad claim; workflow detail needs exact FAQ passage | Use HD-01/HD-02 for summary; HD-04 for FAQ workflow. |
| Offline/guest use | Overview, About and About App describe supported local/guest use without constant internet. FAQ makes stronger “100% offline” claims. | APPROVED WITH QUALIFICATION | Say “supported features” and “guest/local records”; avoid implying every feature works offline. Use HD-03 or HD-04. |
| Local backup vs cloud sync | About App explicitly distinguishes local backup/restore from optional signed-in synchronization. | APPROVED — preserve distinction | Never describe local backup and cloud sync as the same feature. Use HD-03. |
| Sync scope | About App says supported customer, income and expense records may synchronize when signed in and connected. FAQ gives more categorical sync claims. | APPROVED WITH QUALIFICATION | Keep “supported records” and “may/can”; exact merge, conflict resolution and completeness are not established by reviewed text. Use HD-03. |
| PDF reports/statements | Overview/About mention PDF reports/statements; FAQ lists detailed statement fields and export workflow. | APPROVED — broad claim; detailed contents require FAQ wording | Do not generalize the FAQ's specific statement fields to every report type. Use HD-04 for exact FAQ detail. |
| Voice entry | Overview mentions voice entry; FAQ describes Urdu/Roman Urdu/English input and a parsing workflow. | PARTIAL — capability claim supported on site; technical implementation unverified | Avoid accuracy percentages, model architecture or noise-performance guarantees without approved technical evidence. Use HD-04 only for the site's described workflow. |
| Security/encryption/privacy | FAQ includes claims about encrypted SQLite, TLS, Supabase and no external data sharing; About page directs users to Privacy Policy and Terms. | HOLD — owner/legal validation required for strong assurances | Do not repeat “zero data leakage”, specific cryptographic claims, or absolute privacy promises as verified facts. Refer users to current Privacy Policy for policy details. |
| Calculation accuracy | FAQ contains “100% calculation accuracy” language. | HOLD — do not state as guarantee | Can say balances are described as automatically calculated only if a relevant approved source supports it; never promise error-free calculations. |
| Performance/latency/resource usage | FAQ/index include precise performance or resource claims. | HOLD — benchmark evidence required | Do not repeat 11ms, 0s latency, RAM, or accuracy percentages without dated benchmark evidence and owner approval. |
| Pricing / unlimited use | FAQ and index contain free/unlimited claims. | HOLD FOR COMMERCIAL CONFIRMATION | Verify current Play Store listing and product-owner pricing policy before stating “free forever”, unlimited use or no hidden fees. |
| Multi-device access | FAQ says same-account records can sync across devices. | QUALIFIED / OWNER CONFIRMATION | Do not promise real-time collaboration or simultaneous access unless product owner confirms behavior. |
| Company relationship | HisabDo Company page and XICTEK corporate homepage identify HisabDo as an XICTEK product. | APPROVED — company-level claim | Use HD-06 or CX-01; not as feature evidence. |

## C. Discrepancy and risk log

1. **Different levels of detail across pages:** `/`, `/about`, `/about-app`, `/faq`, and `/index` are not equally cautious. The FAQ and versioned index contain stronger technical, security, performance and commercial statements than the overview pages. Use qualified wording and request product-owner approval for strong claims.
2. **Marketing claims vs implementation evidence:** A public webpage is evidence that the website makes a claim; it is not proof that source code, backend configuration, or runtime behavior matches the claim.
3. **Sync semantics:** Reviewed pages describe optional synchronization for supported records but do not fully document conflict handling, record merge rules, deletion propagation or recovery guarantees.
4. **PDF scope:** A customer account statement and a general PDF report may not have identical fields. Do not merge their descriptions.
5. **Corporate-site references:** The corporate website gives a high-level summary of HisabDo. It is not the preferred source for granular product FAQs.
6. **Link integrity:** Recheck the exact URL and target heading at runtime. Do not construct slugs based on titles.

## D. Audit outcome

**Status: PARTIAL PASS — safe high-level claims and official link destinations identified; high-risk technical/commercial claims remain pending owner validation.**

This audit does not certify the live chatbot, retrieval ranking, citation rendering, or the app implementation. The next validation step is to replay the sample transcripts against the deployed chatbot and record the actual retrieved source and final URL for each answer.
