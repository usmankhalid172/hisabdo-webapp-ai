# HisabDo Website References — Grounded Generation Checklist

**Audit date:** 2026-11-12  
**Scope:** Public HisabDo product pages and the XICTEK Systems corporate website  
**Purpose:** Prevent unsupported HisabDo feature claims and ensure response links point to verified, relevant official pages.

## 1. Source selection and authority

- [ ] Retrieve from the official HisabDo domain (`https://hisabdo.app/`) for product features.
- [ ] Use the exact page that supports the claim; prefer a focused FAQ or feature page over a generic homepage.
- [ ] Treat `https://www.xicteksystems.com/` as a company-level source. Use it for the relationship between XICTEK Systems and HisabDo, not as the sole evidence for detailed app behavior.
- [ ] Do not cite unrelated third-party pages, similarly named products, search snippets, or unverified social posts as official product documentation.
- [ ] Preserve the source URL, page title, retrieval date, and relevant heading/snippet in the retrieval record.
- [ ] If two official pages differ, do not silently combine them. Prefer the narrower, less-promissory wording and flag the discrepancy for product-owner review.

## 2. Claim-to-evidence rules

- [ ] Every factual feature claim in the answer must map to retrieved text from an official HisabDo page.
- [ ] Keep the claim no broader than the evidence. “Supported local features work offline” must not become “every feature works offline.”
- [ ] Distinguish guest/local storage, local backup/restore, and signed-in cloud synchronization. They are separate mechanisms.
- [ ] Do not imply that signing in automatically uploads, merges, or preserves every local record unless the retrieved source explicitly explains that behavior.
- [ ] Do not claim security certifications, encryption algorithms, zero data leakage, guaranteed accuracy, uptime, performance, or response-time SLAs unless an approved source explicitly supports the exact claim.
- [ ] Treat precise technical/security/quantitative statements on the FAQ or versioned landing page as **website claims pending owner validation**, not independently verified implementation facts.
- [ ] Do not infer feature availability, platform compatibility, pricing, limits, or current version from old or undated content.
- [ ] If evidence is missing, say “I couldn’t verify that from the official HisabDo pages I found” and offer the closest verified information.

## 3. Inline link policy

- [ ] Product-feature links must use an exact, reviewed `hisabdo.app` URL from the approved link register.
- [ ] Link to the most relevant page (for example, `/faq` for a FAQ-level answer or `/about-app` for local records and sync).
- [ ] Do not link to a search results page, guessed slug, homepage when a focused page exists, or a third-party article.
- [ ] Do not use a corporate XICTEK URL as evidence for a HisabDo feature.
- [ ] A corporate link may be used only for a company-relationship question, and should be clearly labelled as company information.
- [ ] Check that every link resolves and its page still contains the referenced topic before publishing a response.
- [ ] If a link cannot be checked or the destination is not in the approved register, omit it rather than guessing.

## 4. Response construction

- [ ] Answer only the user’s actual question; avoid adding unrequested claims.
- [ ] Attach citations/links immediately after the sentence they support.
- [ ] Keep multiple claims separate if they come from different pages.
- [ ] Use qualified wording where the source uses qualified wording (“supported records”, “optional”, “may”).
- [ ] Never present a source's marketing claim as a tested guarantee.
- [ ] If retrieval returns conflicting pages, explain the ambiguity briefly or ask the user to contact support; do not choose the most impressive claim.
- [ ] If no relevant passage was retrieved, do not generate a plausible answer from general knowledge.

## 5. Suggested retrieval metadata

```json
{
  "product": "HisabDo",
  "domain": "hisabdo.app",
  "source_url": "https://hisabdo.app/faq",
  "page_title": "Frequently Asked Questions & Answers",
  "section_heading": "Does HisabDo work without internet or cellular data?",
  "retrieved_at": "2026-11-12",
  "verification_status": "public_page_reviewed_owner_confirmation_pending",
  "claim_scope": "website_claim_not_independent_implementation_verification"
}
```

## 6. Release acceptance criteria

- 100% of factual feature claims in the test set have an identifiable supporting passage.
- 100% of product links use an approved, relevant `hisabdo.app` URL.
- 0 guessed URLs, unrelated corporate links, or third-party links in product-feature answers.
- 0 unsupported absolutes (for example, “always”, “guaranteed”, “100% secure”, “zero data leakage”).
- 0 conflations between local storage, local backup, and cloud sync.
- All unresolved page conflicts are logged and assigned to a product/content owner.
- A negative test confirms that the chatbot abstains when the source does not support the requested detail.

**Important limitation:** This is a public-page grounding audit. It does not verify application code, backend behavior, privacy implementation, encryption, sync correctness, or the live chatbot’s actual retrieval configuration.
