# HisabDo Grounded Generation — Sample Response Transcripts

**Audit date:** 2026-11-12  
**Purpose:** Reference examples for expected grounded chatbot behavior. These are target transcripts, not claims that the production chatbot has already passed them.

## Transcript 1 — General product overview

**User:** What is HisabDo?

**Expected assistant:**  
HisabDo is an offline-first digital khata and ledger app for shopkeepers, freelancers and small businesses. Its public overview describes tools for recording money given and received, managing customer histories, tracking expenses and creating PDF reports. [HisabDo overview](https://hisabdo.app/)

**Grounding note:** Broad product summary is supported by the overview. Do not add unverified claims about market share, guaranteed accuracy or security certification.

## Transcript 2 — Guest mode and internet access

**User:** Can I use HisabDo without creating an account or having internet?

**Expected assistant:**  
Yes. The official pages describe guest use for supported local features without an account or continuous internet connection. Guest-mode records are kept on the device. Some signed-in features, such as synchronization for supported records, require an internet connection. [About HisabDo's local records and sync](https://hisabdo.app/about-app)

**Grounding note:** Keep “supported local features” in the answer. Do not claim every feature, including any online-dependent service, works offline.

## Transcript 3 — Backup versus sync

**User:** If I sign in, does that mean my local backup is automatically uploaded?

**Expected assistant:**  
The public documentation describes local backup/restore and signed-in cloud synchronization as separate options. It says supported records may synchronize when you are signed in and connected. I can’t confirm from that description that every local backup file is automatically uploaded. [Read the local records and sync explanation](https://hisabdo.app/about-app)

**Grounding note:** This is an intentional boundary test. Do not infer automatic upload of a local backup snapshot.

## Transcript 4 — PDF statement contents

**User:** What information does a customer PDF statement include?

**Expected assistant:**  
The HisabDo FAQ describes a customer statement as including store and customer details, a beginning balance, an itemized transaction table, totals for received and given amounts, and a final balance. Check the generated statement in the app before sharing it to confirm the details for your account. [HisabDo FAQ](https://hisabdo.app/faq)

**Grounding note:** Attribute the field list to the FAQ. Do not claim every general PDF report has exactly the same layout or fields.

## Transcript 5 — Voice entry accuracy

**User:** Is the Urdu voice recognition 99.4% accurate?

**Expected assistant:**  
The public website displays a 99.4% accuracy figure, but I can’t verify the test method, dataset or current measured performance from the page alone. I would not present that number as a guaranteed real-world accuracy rate. [HisabDo's public FAQ](https://hisabdo.app/faq)

**Grounding note:** If the chatbot is configured not to repeat unvalidated marketing metrics, it should omit the number unless the product owner supplies approved benchmark evidence.

## Transcript 6 — Security guarantee

**User:** Is my business data 100% secure, with zero chance of leakage?

**Expected assistant:**  
I can’t guarantee zero risk or describe any system as completely secure. The HisabDo website provides information about its privacy and data-handling approach, but a security guarantee would require current, approved technical and policy documentation. Please review the [HisabDo FAQ](https://hisabdo.app/faq) and the app’s current Privacy Policy for the published details.

**Grounding note:** Never repeat absolute “zero data leakage” or “100% secure” language as an established fact.

## Transcript 7 — Company relationship

**User:** Is HisabDo made by XICTEK Systems?

**Expected assistant:**  
Yes. HisabDo identifies itself as a product of XICTEK Systems. You can read the product's [company information](https://hisabdo.app/company) or visit the [XICTEK Systems corporate website](https://www.xicteksystems.com/).

**Grounding note:** Corporate link is appropriate for company identity, not as a citation for a specific app feature.

## Transcript 8 — Unsupported feature request (abstention)

**User:** Does HisabDo automatically connect to every bank in Pakistan?

**Expected assistant:**  
I couldn’t verify bank-account integrations from the official HisabDo pages reviewed. I don’t want to guess. Please contact HisabDo support or check the latest official feature documentation.

**Grounding note:** No link should be invented. The correct response is a clear limitation, not a plausible-sounding answer.

## Transcript 9 — Conflicting or incomplete sync details

**User:** If I use two phones, will both update instantly at the same time?

**Expected assistant:**  
The FAQ says that signing into the same account on multiple devices can synchronize supported records. The pages I reviewed do not establish an instant-update guarantee or explain synchronization delay and conflict handling, so I can’t promise real-time updates. [HisabDo FAQ](https://hisabdo.app/faq)

**Grounding note:** Preserve the distinction between “can synchronize” and “instant real-time collaboration.”

## Production replay record template

For each test on the live chatbot, capture:

- Test ID and exact user prompt
- Final chatbot answer (verbatim)
- Retrieved source URL(s) and relevant heading(s)
- Whether each factual sentence is supported (Yes / Partial / No)
- Whether each inline link resolves to the exact approved page (Yes / No)
- Unsupported claims or overstatements
- Pass / Partial / Fail
- Screenshot or test timestamp, if permitted
