# Verification Gaps — Careers Knowledge Base
Prepared: 2026-11-09 | Status: Open

| Item | Confirmation required | Owner | Status |
|---|---|---|---|
| Senior Full-Stack Developer | Active/closed status, dates, approved full job description | Engineering hiring owner | Pending |
| Mobile App Developer | Active/closed status, dates, approved full job description | Mobile hiring owner | Pending |
| Cloud Solutions Architect | Active/closed status, dates, approved full job description | Cloud hiring owner | Pending |
| UI/UX Designer | Active/closed status, dates, approved full job description | Design hiring owner | Pending |
| Internship | Application status, cohort dates, capacity, eligibility and roadmap | Program owner | Pending |
| 3–5 business-day response promise | Confirm current recruitment turnaround | HR / recruitment | Pending |
| Careers FAQs | Provide approved FAQ or confirm none exists | HR | Not located publicly |
| Hiring policy | Provide approved policy, version and effective date | HR policy owner | Not provided |

## Purge rule
No listing has been marked expired. Missing dates are a verification flag, not proof of expiry. Remove or archive a listing only after explicit owner confirmation; record approver, decision date, approval reference and removal date.

## Required metadata before production
`document_id`, `document_type`, `department`, `position_category`, `position_title`, `employment_type`, `work_arrangement`, `posting_date`, `closing_date`, `application_status`, `source_url`, `source_owner`, `verified_at`, `verification_status`, `approval_reference`, `content_status`.

Use ISO dates (`YYYY-MM-DD`) and `null` for unknown values.
