# XICTEK Careers Knowledge Set
Status: Draft for HR/hiring-owner verification | Prepared: 2026-11-09

This is a cleaned staging draft based only on public pages. It is not an HR-approved active-vacancy feed. Do not publish pending records or remove listings until the responsible owner confirms status.

Sources:
- https://www.xicteksystems.com/careers
- https://www.xicteksystems.com/careers/internship

Files:
- careers_knowledge.md: cleaned Markdown content with YAML metadata.
- metadata_samples.jsonl: sample metadata objects, one JSON object per line.
- verification_gaps.md: open HR verification items.

Cleaning rules:
- Repeated promotional wording and repeated application calls-to-action are omitted.
- No responsibilities, salary, seniority, qualifications, dates, or policies have been invented.
- Missing posting/closing dates are flags for verification, not proof a role is expired.
- Pending entries belong in staging, not production retrieval.
