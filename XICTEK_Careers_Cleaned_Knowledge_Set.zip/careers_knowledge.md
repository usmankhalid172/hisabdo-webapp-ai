---
document_id: CAREERS-OVERVIEW-001
document_type: careers_overview
department: human_resources
position_category: general
source_url: https://www.xicteksystems.com/careers
reviewed_at: 2026-11-09
verified_at: null
verification_status: pending_hr
content_status: staging_only
---

# Careers at XICTEK Systems

The Careers page describes opportunities for engineers, designers, and problem-solvers. It highlights real-world projects, collaboration, learning opportunities, remote-friendly work arrangements, and career growth.

The page links to open positions and an internship program.

---

---
document_id: JOB-SWE-FULLSTACK-001
document_type: job_listing
department: engineering
position_category: software_development
position_title: Senior Full-Stack Developer
employment_type: full_time
work_arrangement: remote
technology_tags: [React, Next.js, .NET, PostgreSQL]
source_url: https://www.xicteksystems.com/careers
reviewed_at: 2026-11-09
verified_at: null
posting_date: null
closing_date: null
application_status: unconfirmed
verification_status: pending_hr
content_status: staging_only
---

# Senior Full-Stack Developer
- Department: Engineering
- Category: Software Development
- Employment: Full-time
- Work arrangement: Remote
- Technology tags shown: React, Next.js, .NET, PostgreSQL

The public page labels this role under “Current Openings.” Active hiring status is not confirmed. Detailed responsibilities, qualifications, seniority, compensation, posting date, and closing date were not visible in the reviewed page text. Do not infer these details.

---

---
document_id: JOB-MOBILE-APP-001
document_type: job_listing
department: engineering
position_category: mobile_development
position_title: Mobile App Developer
employment_type: full_time
work_arrangement: remote
technology_tags: [Flutter, React Native, iOS, Android]
source_url: https://www.xicteksystems.com/careers
reviewed_at: 2026-11-09
verified_at: null
posting_date: null
closing_date: null
application_status: unconfirmed
verification_status: pending_hr
content_status: staging_only
---

# Mobile App Developer
- Department: Engineering
- Category: Mobile Development
- Employment: Full-time
- Work arrangement: Remote
- Technology tags shown: Flutter, React Native, iOS, Android

The public page labels this role under “Current Openings.” Active hiring status is not confirmed. Detailed responsibilities, qualifications, seniority, compensation, posting date, and closing date were not visible in the reviewed page text. Do not infer these details.

---

---
document_id: JOB-CLOUD-ARCH-001
document_type: job_listing
department: cloud_and_infrastructure
position_category: cloud_architecture
position_title: Cloud Solutions Architect
employment_type: full_time
work_arrangement: remote
technology_tags: [Azure, AWS, DevOps, Terraform]
source_url: https://www.xicteksystems.com/careers
reviewed_at: 2026-11-09
verified_at: null
posting_date: null
closing_date: null
application_status: unconfirmed
verification_status: pending_hr
content_status: staging_only
---

# Cloud Solutions Architect
- Department: Cloud and Infrastructure
- Category: Cloud Architecture
- Employment: Full-time
- Work arrangement: Remote
- Technology tags shown: Azure, AWS, DevOps, Terraform

The public page labels this role under “Current Openings.” Active hiring status is not confirmed. Detailed responsibilities, qualifications, seniority, compensation, posting date, and closing date were not visible in the reviewed page text. Do not infer these details.

---

---
document_id: JOB-UIUX-DESIGN-001
document_type: job_listing
department: design
position_category: ui_ux_design
position_title: UI/UX Designer
employment_type: full_time
work_arrangement: remote
technology_tags: [Figma, Design Systems, Prototyping]
source_url: https://www.xicteksystems.com/careers
reviewed_at: 2026-11-09
verified_at: null
posting_date: null
closing_date: null
application_status: unconfirmed
verification_status: pending_hr
content_status: staging_only
---

# UI/UX Designer
- Department: Design
- Category: UI/UX Design
- Employment: Full-time
- Work arrangement: Remote
- Technology tags shown: Figma, Design Systems, Prototyping

The public page labels this role under “Current Openings.” Active hiring status is not confirmed. Detailed responsibilities, qualifications, seniority, compensation, posting date, and closing date were not visible in the reviewed page text. Do not infer these details.

---

---
document_id: CAREERS-INTERNSHIP-001
document_type: internship_program
department: human_resources
position_category: internship
program_duration_weeks: 12
source_url: https://www.xicteksystems.com/careers/internship
reviewed_at: 2026-11-09
verified_at: null
verification_status: pending_program_owner
content_status: staging_only
---

# XICTEK Systems Internship Program

The public page describes a 12-week structured internship for students and recent graduates.

## Published eligibility
- Currently enrolled in or recently graduated from Computer Science, Software Engineering, or a related program.
- Basic knowledge of at least one programming language.
- Eagerness to learn and take on challenges.
- Communication and teamwork skills.
- Ability to commit to the full 12-week program.

## Published roadmap
- Weeks 1–2: onboarding, codebase walkthrough, tools setup, team introduction.
- Weeks 3–6: guided development, real tasks, mentorship, code reviews.
- Weeks 7–10: independent contribution, feature work, production deployment contributions.
- Weeks 11–12: capstone, review, feedback, discussion of next steps.

## Published benefits
Real project work, mentorship, collaborative team environment, and possible full-time offers for strong candidates. A full-time offer is not guaranteed.

## Application turnaround statement
The page states applications will be reviewed within 3–5 business days. HR must confirm whether this statement remains current.

---

---
document_id: CAREERS-FAQ-PLACEHOLDER-001
document_type: faq_status
department: human_resources
position_category: general
source_url: https://www.xicteksystems.com/careers
reviewed_at: 2026-11-09
verified_at: null
verification_status: not_located_publicly
content_status: staging_only
---

# Careers FAQ source status

No dedicated public Careers FAQ page was located during this review. This is a source-status note, not a candidate-facing FAQ. HR should provide approved FAQs or confirm that no separate FAQ source is maintained.

---

---
document_id: HIRING-POLICY-PLACEHOLDER-001
document_type: policy_status
department: human_resources
position_category: general
source_url: null
reviewed_at: 2026-11-09
verified_at: null
verification_status: not_provided
content_status: staging_only
---

# Hiring policy source status

No approved public hiring-policy document was provided or located in the reviewed public Careers pages. Request the current approved HR policy, owner, version, approval reference, and effective date. Do not answer policy questions from assumptions.
