# Department 4 — Contact/Locations Day 7 Final Validation & Handover

**Prepared by:** Ali Hassan, Team Lead  
**Date:** 2026-11-04  
**Scope:** XICTEK Systems Contact Us and Office Locations  
**Disposition:** **RELEASE NOT CLEARED — blocking live quality and citation defects**

## Executive summary

The 15-question Day 7 set was sent to the local XICTEK assistant API using its built index and a **mock LLM provider**. All 15 requests returned HTTP 200, but only 6 of 15 records included the exact official Contact URL in the reply or source references, and this mocked run does not establish production answer quality.

Three representative questions were also tested through the public website assistant. They exposed release-blocking defects:

- The assistant incorrectly described optional contact-form fields as required.
- An office-location question returned unrelated HisabDo business-expense content.
- A street-address question returned a HisabDo support email and unrelated links.

The public Contact page currently displays `xicteksystems@gmail.com` and marks Full Name, Email Address, and Message as required; Phone Number and Company have no required marker. The reviewed page did not show an office address or office hours. The assistant must use current page content and abstain for unpublished location details.

## Evaluation execution and evidence

| Run | Scope | Result | Interpretation |
|---|---|---|---|
| Local Day 7 API run | All 15 fixture questions, local API, index reported built with 976 chunks, `LLM_PROVIDER=mock` | 15/15 HTTP 200; 9 responses returned source references; 6/15 included the exact Contact URL; median in-process request time 16 ms | API-path smoke evidence only. Mock output and in-process timing are not production accuracy or latency results. |
| Local XICTEK module tests | `tests/xictek_website_assistant` | 114 passed, 0 failed; one dependency deprecation warning | Local automated regression suite passed. Does not verify the deployed website assistant. |
| Local retrieval/generation tests | 15-query fixtures and retrieval tests | 13 passed, 0 failed | Fixture-based tests passed; not an independent production evaluation. |
| Public widget checks | Q04, Q06, Q07 on the official Contact page | 3 checks; all exposed inaccurate or irrelevant output | Fails the quality, domain-grounding, and citation expectations. |

The original grounded-generation test utility had an import typo (`typing.any`); it was corrected to `typing.Any` so the tests could run. This was a test-utility-only correction, not a production assistant change.

## Public widget findings

Official page checked: [XICTEK Contact Us](https://www.xicteksystems.com/contact)

| ID | Evaluation question | Observed public assistant response | Result |
|---|---|---|---|
| Q04 | Which fields are required on the inquiry form? | Said “Name, email, phone, company, and message” and linked to unrelated .NET and HisabDo pages. The visible form marks only Full Name, Email Address, and Message as required. | **FAIL** — incorrect required-field guidance and irrelevant citations. |
| Q06 | Where is the XICTEK office located? | Returned a list of business-expense categories and a HisabDo blog link. | **FAIL** — unrelated cross-domain retrieval; no location abstention. |
| Q07 | What is the company's street address and city? | Returned `support@hisabdo.app` with links to HisabDo Media and an XICTEK mobile-development blog. | **FAIL** — wrong answer type and cross-domain references. |

The widget was slow during these checks; one response was still present when a 45-second wait for the send control to re-enable timed out. These browser waits are not server-measured latency and should not be reported as exact endpoint timings.

## Release clearance checklist

| Criterion | Status | Evidence / gap |
|---|---|---|
| Day 7 fixture questions exercised against local API | **PASS — limited** | 15/15 returned HTTP 200 with mock LLM; answer quality was not validated by that mock run. |
| Local assistant regression tests | **PASS — local only** | 114 passed; deployed-version parity is unverified. |
| Correct required-form fields on public widget | **FAIL** | Q04 incorrectly labels optional phone/company fields as required. |
| Contact/location domain isolation | **FAIL** | Q06 and Q07 returned HisabDo content and links. |
| Relevant official citations | **FAIL** | Public Q04, Q06, and Q07 evidence contains unrelated citations; local mock run had the exact Contact URL in only 6/15 records (reply or source references). |
| Safe abstention for unpublished office address | **FAIL** | Q06 did not abstain; Q07 produced an unrelated email instead. |
| Full 15-question public-widget evaluation | **NOT COMPLETE** | Only 3/15 were exercised on the public widget; local mock evaluation is not a substitute. |
| Production build/index/model identity and deployment parity | **NOT VERIFIED** | The public assistant's serving version could not be tied to the local source or test index. |
| Production latency and send-control recovery | **NOT CLEARED** | Slow browser responses observed; reliable server-side timing and completion behavior not established. |

## Department 4 handover and required actions

1. **Block release until domain leakage is fixed.** Review the live widget's retrieval filters, source allow-list, and answer/citation association; verify contact questions cannot surface HisabDo-only documents.
2. **Refresh and verify Contact-page grounding.** Use the current official page as the source of truth: published email and form-required markers are visible; street address and office hours were not visible in this check. Do not treat the older fixture's field claims as current page evidence.
3. **Run all 15 questions against the actual release candidate.** Use independent clean conversations, capture full answers, source URLs, model/index version, and server-side latency. Include form fields, email, address, hours, phone, support terms, and prompt-boundary cases.
4. **Investigate widget latency and control state.** Capture client and server timings and confirm the send button becomes usable after both successful and failed requests.
5. **Record deployment parity and ownership.** Department 4 should identify the deployed commit/model/index and assign owners for retrieval, content refresh, and live re-test before requesting sign-off.

**Handover verdict:** **Do not issue Contact/Locations release clearance.** Re-test and obtain a clean independent review after the blocking findings are resolved.

## Supporting files

- [Day 7 evaluation scorecard](./Ali_Hassan_XICTEK_Contact_Locations_Day7_Evaluation_Results_2026-11-04.csv)
- [Prior contact monitoring report](./Ali_Hassan_XICTEK_Contact_Locations_Performance_Monitoring_2026-11-03.md)
- [Prior performance scorecard](./Ali_Hassan_XICTEK_Contact_Locations_Performance_Scorecard_2026-11-03.csv)
- Local module test scope: `internship task\hisabdo-webapp-ai\tests\xictek_website_assistant`
- Local evaluation fixture: `internship task\xictek_contact_locations_retrieval_corpus.json`
